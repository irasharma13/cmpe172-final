var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'malbgal',
applicationName: 'eos',
appUid: 'HHFK3VG8F2y78Fk5gf',
tenantUid: '0GK7QTZtp5V1WjdJnQ',
deploymentUid: '0561fb36-1b7a-462e-b155-fcd9fe7f618d',
serviceName: 'eos',
stageName: 'prod',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'eos-prod-list', timeout: 6}
try {
  const userHandler = require('./list.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
